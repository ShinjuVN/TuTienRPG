# Resource Pack Tu Tiên RPG (Minecraft Java 1.21.11)

## 1. Cấu trúc
```
TuTienRPG-ResourcePack.zip
├─ pack.mcmeta                      (pack_format 75 = 1.21.11)
├─ pack.png
└─ assets/
   ├─ tutien/font/hud.json          font "tutien:hud" (khung, ruột, khoảng cách âm/dương)
   └─ minecraft/textures/gui/
      ├─ rpg/hp_frame.png           102x9  khung bo góc (viền vàng, nền tối)
      ├─ rpg/hp_fill_{1,2,4,8,16,32,64}.png   ruột đỏ, cao 9px (vẽ ở hàng 2..6)
      └─ sprites/hud/heart/*.png    sprite tim vanilla -> trong suốt 9x9 (ẩn tim)
```
Lưu ý: từ 1.20.2 file `icons.png` không còn dùng cho tim; HUD dùng sprite riêng trong
`textures/gui/sprites/hud/heart/`. Ghi đè bằng ảnh trong suốt là cách ẩn tim chuẩn.

## 2. Cách plugin vẽ thanh HP (Action Bar + Custom Font)
Chuỗi gửi lên Action Bar (font tutien:hud, màu trắng):
`[E000 khung] [lùi 100px] [ruột = tổ hợp nhị phân E001..E007, mỗi mảnh kèm lùi 1px] [tiến về cuối khung]`
rồi lùi về giữa, viết "45,200 / 100,000" bằng font mặc định, rồi tiến nốt về cuối khung.
- Ruột tối đa 96px = 100% HP; chiều dài = round(96 * HP / MaxHP).
- Ký tự dịch: E100-E107 = -1,-2,-4,-8,-16,-32,-64,-128 px; E110-E117 = +1..+128 px.
- Vì bitmap glyph luôn có advance = chiều rộng + 1, mỗi mảnh ruột được bù bằng lùi 1px.

## 3. Đồng bộ với plugin
- Cách A (khuyên dùng): upload zip lên host trực tiếp (không redirect), điền `resource-pack.url` và `sha1` trong config.yml của plugin. Plugin gửi pack khi vào server; ai từ chối pack sẽ thấy thanh HP dạng chữ.
- Cách B: đặt `resource-pack=` và `resource-pack-sha1=` trong server.properties, để `resource-pack.url` trống (plugin coi như ai cũng có pack).
- Mỗi lần sửa pack: tính lại SHA-1 và đổi URL (hoặc thêm ?v=2) để client tải lại.

## 4. Tùy chỉnh
- Đổi màu: sửa hp_frame.png / hp_fill_*.png (giữ nguyên kích thước; ruột chỉ tô hàng 2..6, rộng đúng N px, KHÔNG để pixel trong suốt bên cạnh vì glyph bị cắt theo pixel cuối).
- Đổi độ dài thanh: sửa FILL_MAX/FRAME_ADV trong HudManager.java và vẽ lại khung.
- Nếu số HP lệch dọc 1px: chỉnh "ascent" trong hud.json (bitmap khung/ruột) +-1.
- Bóng chữ Action Bar làm viền hơi tối quanh khung; có thể bỏ bằng shadow_color của text component ở bản Adventure mới.
